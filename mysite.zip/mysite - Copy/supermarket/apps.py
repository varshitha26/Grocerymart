from django.apps import AppConfig


class SupermarketConfig(AppConfig):
    name = 'supermarket'
